# Lookup for R5ArtifactUrlClassifierForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ArtifactUrlClassifierForR4

### Lookup for FHIR R5 ValueSet ArtifactUrlClassifier:http://hl7.org/fhir/ValueSet/artifact-url-classifier for use in FHIR R4

The FHIR R5 ValueSet ArtifactUrlClassifier has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/artifact-url-classifier` | `abstract` | Abstract | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `code-repository` | Code repository | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `compressed-file` | Compressed file | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `computable-resource` | Computable resource | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `doi-based` | DOI Based | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `file-directory` | File directory | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `full-text` | Full-Text | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `json` | JSON | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `not-specified` | Not Specified | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `pdf` | PDF | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `restricted` | Restricted | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `supplement` | Supplement | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `version-specific` | Version Specific | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `webpage` | Webpage | Yes |   |   |   |
| `http://hl7.org/fhir/artifact-url-classifier` | `xml` | XML | Yes |   |   |   |

