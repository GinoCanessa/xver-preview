# Lookup for R5GoalPriorityForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5GoalPriorityForR4

### Lookup for FHIR R5 ValueSet GoalPriority:http://hl7.org/fhir/ValueSet/goal-priority for use in FHIR R4

The FHIR R5 ValueSet GoalPriority maps to the FHIR R4 ValueSet GoalPriority:[`http://hl7.org/fhir/ValueSet/goal-priority`](https://hl7.org/fhir/R4/valueset-goal-priority.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/goal-priority` | `high-priority` | High Priority | No | `http://terminology.hl7.org/CodeSystem/goal-priority` | `high-priority` | High Priority |
| `http://terminology.hl7.org/CodeSystem/goal-priority` | `low-priority` | Low Priority | No | `http://terminology.hl7.org/CodeSystem/goal-priority` | `low-priority` | Low Priority |
| `http://terminology.hl7.org/CodeSystem/goal-priority` | `medium-priority` | Medium Priority | No | `http://terminology.hl7.org/CodeSystem/goal-priority` | `medium-priority` | Medium Priority |

