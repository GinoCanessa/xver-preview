# Lookup for R5ClaimOutcomeForR4RemittanceOutcome - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClaimOutcomeForR4RemittanceOutcome

### Lookup for FHIR R5 ValueSet ClaimProcessingCodes:http://hl7.org/fhir/ValueSet/claim-outcome for use in FHIR R4

The FHIR R5 ValueSet ClaimProcessingCodes maps to the FHIR R4 ValueSet ClaimProcessingCodes:[`http://hl7.org/fhir/ValueSet/remittance-outcome`](https://hl7.org/fhir/R4/valueset-remittance-outcome.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/claim-outcome` | `complete` | Processing Complete | No | `http://hl7.org/fhir/remittance-outcome` | `complete` | Processing Complete |
| `http://hl7.org/fhir/claim-outcome` | `error` | Error | No | `http://hl7.org/fhir/remittance-outcome` | `error` | Error |
| `http://hl7.org/fhir/claim-outcome` | `partial` | Partial Processing | No | `http://hl7.org/fhir/remittance-outcome` | `partial` | Partial Processing |
| `http://hl7.org/fhir/claim-outcome` | `queued` | Queued | No | `http://hl7.org/fhir/remittance-outcome` | `queued` | Queued |

