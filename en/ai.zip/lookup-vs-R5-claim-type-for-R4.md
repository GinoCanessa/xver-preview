# Lookup for R5ClaimTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClaimTypeForR4

### Lookup for FHIR R5 ValueSet ClaimTypeCodes:http://hl7.org/fhir/ValueSet/claim-type for use in FHIR R4

The FHIR R5 ValueSet ClaimTypeCodes maps to the FHIR R4 ValueSet ClaimTypeCodes:[`http://hl7.org/fhir/ValueSet/claim-type`](https://hl7.org/fhir/R4/valueset-claim-type.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/claim-type` | `institutional` | Institutional | No | `http://terminology.hl7.org/CodeSystem/claim-type` | `institutional` | Institutional |
| `http://terminology.hl7.org/CodeSystem/claim-type` | `oral` | Oral | No | `http://terminology.hl7.org/CodeSystem/claim-type` | `oral` | Oral |
| `http://terminology.hl7.org/CodeSystem/claim-type` | `pharmacy` | Pharmacy | No | `http://terminology.hl7.org/CodeSystem/claim-type` | `pharmacy` | Pharmacy |
| `http://terminology.hl7.org/CodeSystem/claim-type` | `professional` | Professional | No | `http://terminology.hl7.org/CodeSystem/claim-type` | `professional` | Professional |
| `http://terminology.hl7.org/CodeSystem/claim-type` | `vision` | Vision | No | `http://terminology.hl7.org/CodeSystem/claim-type` | `vision` | Vision |

