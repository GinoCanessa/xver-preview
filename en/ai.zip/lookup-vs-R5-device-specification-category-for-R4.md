# Lookup for R5DeviceSpecificationCategoryForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5DeviceSpecificationCategoryForR4

### Lookup for FHIR R5 ValueSet DeviceSpecificationCategory:http://hl7.org/fhir/ValueSet/device-specification-category for use in FHIR R4

The FHIR R5 ValueSet DeviceSpecificationCategory has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/device-specification-category` | `communication` | Communication | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `electrical` | Electrical | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `exchange` | Exchange | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `material` | Material | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `measurement` | Measurement | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `performance` | Performance | Yes |   |   |   |
| `http://hl7.org/fhir/device-specification-category` | `risk-class` | Risk Class | Yes |   |   |   |

