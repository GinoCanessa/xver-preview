# Lookup for R5ContributorSummarySourceForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContributorSummarySourceForR4

### Lookup for FHIR R5 ValueSet ContributorSummarySource:http://hl7.org/fhir/ValueSet/contributor-summary-source for use in FHIR R4

The FHIR R5 ValueSet ContributorSummarySource has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/contributor-summary-source` | `article-copy` | Copied from article | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-source` | `citation-manager` | Reported by citation manager | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-source` | `custom` | custom format | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-source` | `publisher-data` | Publisher provided | Yes |   |   |   |

