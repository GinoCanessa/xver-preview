# Lookup for R5EventCapabilityModeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5EventCapabilityModeForR4

### Lookup for FHIR R5 ValueSet EventCapabilityMode:http://hl7.org/fhir/ValueSet/event-capability-mode for use in FHIR R4

The FHIR R5 ValueSet EventCapabilityMode maps to the FHIR R4 ValueSet EventCapabilityMode:[`http://hl7.org/fhir/ValueSet/event-capability-mode`](https://hl7.org/fhir/R4/valueset-event-capability-mode.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/event-capability-mode` | `receiver` | Receiver | No | `http://hl7.org/fhir/event-capability-mode` | `receiver` | Receiver |
| `http://hl7.org/fhir/event-capability-mode` | `sender` | Sender | No | `http://hl7.org/fhir/event-capability-mode` | `sender` | Sender |

