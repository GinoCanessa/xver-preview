# Lookup for R5AllergIntolSubstanceExpRiskForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5AllergIntolSubstanceExpRiskForR4

### Lookup for FHIR R5 ValueSet AllergyIntoleranceSubstanceExposureRisk:http://terminology.hl7.org/ValueSet/allerg-intol-substance-exp-risk for use in FHIR R4

The FHIR R5 ValueSet AllergyIntoleranceSubstanceExposureRisk has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/allerg-intol-substance-exp-risk` | `known-reaction-risk` | Known Reaction Risk | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/allerg-intol-substance-exp-risk` | `no-known-reaction-risk` | No Known Reaction Risk | Yes |   |   |   |

