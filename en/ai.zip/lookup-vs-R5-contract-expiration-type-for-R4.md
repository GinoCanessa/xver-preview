# Lookup for R5ContractExpirationTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContractExpirationTypeForR4

### Lookup for FHIR R5 ValueSet ContractResourceExpirationTypeCodes:http://hl7.org/fhir/ValueSet/contract-expiration-type for use in FHIR R4

The FHIR R5 ValueSet ContractResourceExpirationTypeCodes maps to the FHIR R4 ValueSet ContractResourceExpirationTypeCodes:[`http://hl7.org/fhir/ValueSet/contract-expiration-type`](https://hl7.org/fhir/R4/valueset-contract-expiration-type.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/contract-expiration-type` | `breach` | Breach | No | `http://hl7.org/fhir/contract-expiration-type` | `breach` | Breach |

