# Lookup for R5ConditionVerStatusForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ConditionVerStatusForR4

### Lookup for FHIR R5 ValueSet ConditionVerificationStatus:http://hl7.org/fhir/ValueSet/condition-ver-status for use in FHIR R4

The FHIR R5 ValueSet ConditionVerificationStatus maps to the FHIR R4 ValueSet ConditionVerificationStatus:[`http://hl7.org/fhir/ValueSet/condition-ver-status`](https://hl7.org/fhir/R4/valueset-condition-ver-status.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `confirmed` | Confirmed | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `confirmed` | Confirmed |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `differential` | Differential | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `differential` | Differential |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `entered-in-error` | Entered in Error | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `entered-in-error` | Entered in Error |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `provisional` | Provisional | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `provisional` | Provisional |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `refuted` | Refuted | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `refuted` | Refuted |
| `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `unconfirmed` | Unconfirmed | No | `http://terminology.hl7.org/CodeSystem/condition-ver-status` | `unconfirmed` | Unconfirmed |

