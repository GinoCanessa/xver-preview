# Lookup for R5ClaimCareteamroleForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClaimCareteamroleForR4

### Lookup for FHIR R5 ValueSet ClaimCareTeamRoleCodes:http://hl7.org/fhir/ValueSet/claim-careteamrole for use in FHIR R4

The FHIR R5 ValueSet ClaimCareTeamRoleCodes maps to the FHIR R4 ValueSet ClaimCareTeamRoleCodes:[`http://hl7.org/fhir/ValueSet/claim-careteamrole`](https://hl7.org/fhir/R4/valueset-claim-careteamrole.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `assist` | Assisting Provider | No | `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `assist` | Assisting Provider |
| `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `other` | Other | No | `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `other` | Other |
| `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `primary` | Primary provider | No | `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `primary` | Primary provider |
| `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `supervisor` | Supervising Provider | No | `http://terminology.hl7.org/CodeSystem/claimcareteamrole` | `supervisor` | Supervising Provider |

