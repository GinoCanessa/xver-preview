# Lookup for R5ActionReasonCodeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ActionReasonCodeForR4

### Lookup for FHIR R5 ValueSet ActionReasonCode:http://hl7.org/fhir/ValueSet/action-reason-code for use in FHIR R4

The FHIR R5 ValueSet ActionReasonCode has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/action-reason-code` | `care-gap` | Care gap detected | Yes |   |   |   |
| `http://hl7.org/fhir/action-reason-code` | `drug-drug-interaction` | Drug-drug interaction | Yes |   |   |   |
| `http://hl7.org/fhir/action-reason-code` | `off-pathway` | Off pathway | Yes |   |   |   |
| `http://hl7.org/fhir/action-reason-code` | `quality-measure` | Quality measure | Yes |   |   |   |
| `http://hl7.org/fhir/action-reason-code` | `risk-assessment` | Risk assessment | Yes |   |   |   |

