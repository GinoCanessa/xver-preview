# Lookup for R5AdverseEventActualityForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5AdverseEventActualityForR4

### Lookup for FHIR R5 ValueSet AdverseEventActuality:http://hl7.org/fhir/ValueSet/adverse-event-actuality for use in FHIR R4

The FHIR R5 ValueSet AdverseEventActuality maps to the FHIR R4 ValueSet AdverseEventActuality:[`http://hl7.org/fhir/ValueSet/adverse-event-actuality`](https://hl7.org/fhir/R4/valueset-adverse-event-actuality.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/adverse-event-actuality` | `actual` | Adverse Event | No | `http://hl7.org/fhir/adverse-event-actuality` | `actual` | Adverse Event |
| `http://hl7.org/fhir/adverse-event-actuality` | `potential` | Potential Adverse Event | No | `http://hl7.org/fhir/adverse-event-actuality` | `potential` | Potential Adverse Event |

