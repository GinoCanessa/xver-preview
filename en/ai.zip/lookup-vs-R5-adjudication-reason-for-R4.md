# Lookup for R5AdjudicationReasonForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5AdjudicationReasonForR4

### Lookup for FHIR R5 ValueSet AdjudicationReasonCodes:http://hl7.org/fhir/ValueSet/adjudication-reason for use in FHIR R4

The FHIR R5 ValueSet AdjudicationReasonCodes maps to the FHIR R4 ValueSet AdjudicationReasonCodes:[`http://hl7.org/fhir/ValueSet/adjudication-reason`](https://hl7.org/fhir/R4/valueset-adjudication-reason.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/adjudication-reason` | `ar001` | Not covered | No | `http://terminology.hl7.org/CodeSystem/adjudication-reason` | `ar001` | Not covered |
| `http://terminology.hl7.org/CodeSystem/adjudication-reason` | `ar002` | Plan Limit Reached | No | `http://terminology.hl7.org/CodeSystem/adjudication-reason` | `ar002` | Plan Limit Reached |

