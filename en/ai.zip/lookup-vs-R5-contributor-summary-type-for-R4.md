# Lookup for R5ContributorSummaryTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContributorSummaryTypeForR4

### Lookup for FHIR R5 ValueSet ContributorSummaryType:http://hl7.org/fhir/ValueSet/contributor-summary-type for use in FHIR R4

The FHIR R5 ValueSet ContributorSummaryType has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/contributor-summary-type` | `acknowledgement-list` | Acknowledgment list | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `acknowledgment-statement` | Acknowledgment statement | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `author-string` | Author string | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `competing-interests-statement` | Competing interests statement | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `contributorship-list` | Contributorship list | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `contributorship-statement` | Contributorship statement | Yes |   |   |   |
| `http://hl7.org/fhir/contributor-summary-type` | `funding-statement` | Funding statement | Yes |   |   |   |

