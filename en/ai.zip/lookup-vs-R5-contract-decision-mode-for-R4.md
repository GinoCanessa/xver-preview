# Lookup for R5ContractDecisionModeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContractDecisionModeForR4

### Lookup for FHIR R5 ValueSet ContractResourceDecisionModeCodes:http://hl7.org/fhir/ValueSet/contract-decision-mode for use in FHIR R4

The FHIR R5 ValueSet ContractResourceDecisionModeCodes maps to the FHIR R4 ValueSet ContractResourceDecisionModeCodes:[`http://hl7.org/fhir/ValueSet/contract-decision-mode`](https://hl7.org/fhir/R4/valueset-contract-decision-mode.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/contract-decision-mode` | `policy` | Policy | No | `http://hl7.org/fhir/contract-decision-mode` | `policy` | Policy |

