# Lookup for R5DefinitionTopicForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5DefinitionTopicForR4

### Lookup for FHIR R5 ValueSet DefinitionTopic:http://hl7.org/fhir/ValueSet/definition-topic for use in FHIR R4

The FHIR R5 ValueSet DefinitionTopic maps to the FHIR R4 ValueSet DefinitionTopic:[`http://hl7.org/fhir/ValueSet/definition-topic`](https://hl7.org/fhir/R4/valueset-definition-topic.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/definition-topic` | `assessment` | Assessment | No | `http://terminology.hl7.org/CodeSystem/definition-topic` | `assessment` | Assessment |
| `http://terminology.hl7.org/CodeSystem/definition-topic` | `education` | Education | No | `http://terminology.hl7.org/CodeSystem/definition-topic` | `education` | Education |
| `http://terminology.hl7.org/CodeSystem/definition-topic` | `treatment` | Treatment | No | `http://terminology.hl7.org/CodeSystem/definition-topic` | `treatment` | Treatment |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `archetype` | Domain Analysis Model | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `custom-resource` | Custom Resource | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `dam` | Domain Analysis Model | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `fhir-structure` | FHIR Structure | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `template` | Template | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/definition-use` | `wire-format` | Wire Format | Yes |   |   |   |

