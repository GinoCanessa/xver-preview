# Lookup for R5CodesystemContentModeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CodesystemContentModeForR4

### Lookup for FHIR R5 ValueSet CodeSystemContentMode:http://hl7.org/fhir/ValueSet/codesystem-content-mode for use in FHIR R4

The FHIR R5 ValueSet CodeSystemContentMode maps to the FHIR R4 ValueSet CodeSystemContentMode:[`http://hl7.org/fhir/ValueSet/codesystem-content-mode`](https://hl7.org/fhir/R4/valueset-codesystem-content-mode.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/codesystem-content-mode` | `complete` | Complete | No | `http://hl7.org/fhir/codesystem-content-mode` | `complete` | Complete |
| `http://hl7.org/fhir/codesystem-content-mode` | `example` | Example | No | `http://hl7.org/fhir/codesystem-content-mode` | `example` | Example |
| `http://hl7.org/fhir/codesystem-content-mode` | `fragment` | Fragment | No | `http://hl7.org/fhir/codesystem-content-mode` | `fragment` | Fragment |
| `http://hl7.org/fhir/codesystem-content-mode` | `not-present` | Not Present | No | `http://hl7.org/fhir/codesystem-content-mode` | `not-present` | Not Present |
| `http://hl7.org/fhir/codesystem-content-mode` | `supplement` | Supplement | No | `http://hl7.org/fhir/codesystem-content-mode` | `supplement` | Supplement |

