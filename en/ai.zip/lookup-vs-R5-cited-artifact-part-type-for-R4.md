# Lookup for R5CitedArtifactPartTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CitedArtifactPartTypeForR4

### Lookup for FHIR R5 ValueSet CitedArtifactPartType:http://hl7.org/fhir/ValueSet/cited-artifact-part-type for use in FHIR R4

The FHIR R5 ValueSet CitedArtifactPartType has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/cited-artifact-part-type` | `article-set` | Part of an article set | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `figures` | figures | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `lines` | lines | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `pages` | pages | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `paragraphs` | paragraphs | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `sections` | sections | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `supplement` | Supplement or Appendix | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `supplement-subpart` | Supplement or Appendix Subpart | Yes |   |   |   |
| `http://hl7.org/fhir/cited-artifact-part-type` | `tables` | tables | Yes |   |   |   |

