# Lookup for R5ContractSubtypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContractSubtypeForR4

### Lookup for FHIR R5 ValueSet ContractSubtypeCodes:http://hl7.org/fhir/ValueSet/contract-subtype for use in FHIR R4

The FHIR R5 ValueSet ContractSubtypeCodes maps to the FHIR R4 ValueSet ContractSubtypeCodes:[`http://hl7.org/fhir/ValueSet/contract-subtype`](https://hl7.org/fhir/R4/valueset-contract-subtype.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/contractsubtypecodes` | `disclosure-ca` | Disclosure-CA | No | `http://terminology.hl7.org/CodeSystem/contractsubtypecodes` | `disclosure-ca` | Disclosure-CA |
| `http://terminology.hl7.org/CodeSystem/contractsubtypecodes` | `disclosure-us` | Disclosure-US | No | `http://terminology.hl7.org/CodeSystem/contractsubtypecodes` | `disclosure-us` | Disclosure-US |

