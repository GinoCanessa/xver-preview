# Lookup for R5ClaimModifiersForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClaimModifiersForR4

### Lookup for FHIR R5 ValueSet ModifierTypeCodes:http://hl7.org/fhir/ValueSet/claim-modifiers for use in FHIR R4

The FHIR R5 ValueSet ModifierTypeCodes maps to the FHIR R4 ValueSet ModifierTypeCodes:[`http://hl7.org/fhir/ValueSet/claim-modifiers`](https://hl7.org/fhir/R4/valueset-claim-modifiers.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `a` | Repair of prior service or installation | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `a` | Repair of prior service or installation |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `b` | Temporary service or installation | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `b` | Temporary service or installation |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `c` | TMJ treatment | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `c` | TMJ treatment |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `e` | Implant or associated with an implant | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `e` | Implant or associated with an implant |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `rooh` | Rush or Outside of office hours | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `rooh` | Rush or Outside of office hours |
| `http://terminology.hl7.org/CodeSystem/modifiers` | `x` | None | No | `http://terminology.hl7.org/CodeSystem/modifiers` | `x` | None |

