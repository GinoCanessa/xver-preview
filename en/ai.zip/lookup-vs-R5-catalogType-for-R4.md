# Lookup for R5CatalogTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CatalogTypeForR4

### Lookup for FHIR R5 ValueSet CatalogType:http://hl7.org/fhir/ValueSet/catalogType for use in FHIR R4

The FHIR R5 ValueSet CatalogType maps to the FHIR R4 ValueSet CatalogType:[`http://hl7.org/fhir/ValueSet/catalogType`](https://hl7.org/fhir/R4/valueset-catalogType.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/catalogType` | `device` | Device Catalog | No | `http://terminology.hl7.org/CodeSystem/catalogType` | `device` | Device Catalog |
| `http://hl7.org/fhir/catalogType` | `medication` | Medication Catalog | No | `http://terminology.hl7.org/CodeSystem/catalogType` | `medication` | Medication Catalog |
| `http://hl7.org/fhir/catalogType` | `protocol` | Protocol List | No | `http://terminology.hl7.org/CodeSystem/catalogType` | `protocol` | Protocol List |

