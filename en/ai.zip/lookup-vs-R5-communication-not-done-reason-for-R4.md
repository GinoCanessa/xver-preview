# Lookup for R5CommunicationNotDoneReasonForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CommunicationNotDoneReasonForR4

### Lookup for FHIR R5 ValueSet CommunicationNotDoneReason:http://hl7.org/fhir/ValueSet/communication-not-done-reason for use in FHIR R4

The FHIR R5 ValueSet CommunicationNotDoneReason maps to the FHIR R4 ValueSet CommunicationNotDoneReason:[`http://hl7.org/fhir/ValueSet/communication-not-done-reason`](https://hl7.org/fhir/R4/valueset-communication-not-done-reason.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `family-objection` | Family Objection | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `family-objection` | Family Objection |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `invalid-phone-number` | Invalid Phone Number | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `invalid-phone-number` | Invalid Phone Number |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `patient-objection` | Patient Objection | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `patient-objection` | Patient Objection |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `recipient-unavailable` | Recipient Unavailable | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `recipient-unavailable` | Recipient Unavailable |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `system-error` | System Error | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `system-error` | System Error |
| `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `unknown` | Unknown | No | `http://terminology.hl7.org/CodeSystem/communication-not-done-reason` | `unknown` | Unknown |

