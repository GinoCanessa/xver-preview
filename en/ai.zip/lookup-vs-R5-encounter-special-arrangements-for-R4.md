# Lookup for R5EncounterSpecialArrangementsForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5EncounterSpecialArrangementsForR4

### Lookup for FHIR R5 ValueSet SpecialArrangements:http://hl7.org/fhir/ValueSet/encounter-special-arrangements for use in FHIR R4

The FHIR R5 ValueSet SpecialArrangements maps to the FHIR R4 ValueSet SpecialArrangements:[`http://hl7.org/fhir/ValueSet/encounter-special-arrangements`](https://hl7.org/fhir/R4/valueset-encounter-special-arrangements.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `add-bed` | Additional bedding | No | `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `add-bed` | Additional bedding |
| `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `att` | Attendant | No | `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `att` | Attendant |
| `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `dog` | Guide dog | No | `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `dog` | Guide dog |
| `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `int` | Interpreter | No | `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `int` | Interpreter |
| `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `wheel` | Wheelchair | No | `http://terminology.hl7.org/CodeSystem/encounter-special-arrangements` | `wheel` | Wheelchair |

