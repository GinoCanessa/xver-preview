# Lookup for Profile_R5_Library_R4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for Profile_R5_Library_R4

### Lookup for FHIR R5 Library for use in FHIR R4

The FHIR R5 resource is represented in FHIR R4 via the Library resource.

Note that there is a profile defined to simplify use of this cross-version resource representation:[Profile: Library](StructureDefinition-profile-Library.md)

A computable version of the following element information is available in: [R5LibraryElementMapToR4](ConceptMap-R5-Library-element-map-to-R4.md)

| | | |
| :--- | :--- | :--- |
| [`Library`](https://hl7.org/fhir/R5/Library.html#resource) |   |   |
| [`Library.meta`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.meta](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.meta`is mapped to FHIR R4 element`Library.meta`as`Equivalent`. |
| [`Library.implicitRules`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.implicitRules](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.implicitRules`is mapped to FHIR R4 element`Library.implicitRules`as`Equivalent`. |
| [`Library.language`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.language](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.language`is mapped to FHIR R4 element`Library.language`as`Equivalent`. |
| [`Library.text`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.text](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.text`is mapped to FHIR R4 element`Library.text`as`Equivalent`. |
| [`Library.contained`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.contained](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.contained`is mapped to FHIR R4 element`Library.contained`as`Equivalent`. |
| [`Library.url`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.url](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.url`is mapped to FHIR R4 element`Library.url`as`Equivalent`. |
| [`Library.identifier`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.identifier](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.identifier`is mapped to FHIR R4 element`Library.identifier`as`Equivalent`. |
| [`Library.version`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.version](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.version`is mapped to FHIR R4 element`Library.version`as`Equivalent`. |
| [`Library.versionAlgorithm[x]`](https://hl7.org/fhir/R5/Library.html#resource) | [Extension: ExtensionLibrary_VersionAlgorithm](StructureDefinition-ext-R5-Library.versionAlgorithm.md) | Element`Library.versionAlgorithm[x]`has a context of Library based on following the parent source element upwards and mapping to`Library`.Element`Library.versionAlgorithm[x]`has no mapping targets in FHIR R4. Typically, this is because the element has been added (is a new element). |
| [`Library.name`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.name](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.name`is mapped to FHIR R4 element`Library.name`as`Equivalent`. |
| [`Library.title`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.title](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.title`is mapped to FHIR R4 element`Library.title`as`Equivalent`. |
| [`Library.subtitle`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.subtitle](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.subtitle`is mapped to FHIR R4 element`Library.subtitle`as`Equivalent`. |
| [`Library.status`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.status](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.status`is mapped to FHIR R4 element`Library.status`as`Equivalent`. |
| [`Library.experimental`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.experimental](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.experimental`is mapped to FHIR R4 element`Library.experimental`as`Equivalent`. |
| [`Library.type`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.type](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.type`is mapped to FHIR R4 element`Library.type`as`Equivalent`. |
| [`Library.subject[x]`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.subject[x]](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.subject[x]`is mapped to FHIR R4 element`Library.subject[x]`as`Equivalent`.The target context`Library.subject[x]`is a choice-type element and cannot directly hold extensions. The context is moved up to parent element`Library`. |
| [`Library.date`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.date](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.date`is mapped to FHIR R4 element`Library.date`as`Equivalent`. |
| [`Library.publisher`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.publisher](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.publisher`is mapped to FHIR R4 element`Library.publisher`as`Equivalent`. |
| [`Library.contact`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.contact](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.contact`is mapped to FHIR R4 element`Library.contact`as`Equivalent`. |
| [`Library.description`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.description](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.description`is mapped to FHIR R4 element`Library.description`as`Equivalent`. |
| [`Library.useContext`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.useContext](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.useContext`is mapped to FHIR R4 element`Library.useContext`as`Equivalent`. |
| [`Library.jurisdiction`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.jurisdiction](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.jurisdiction`is mapped to FHIR R4 element`Library.jurisdiction`as`Equivalent`.Element`Library.jurisdiction`has been flagged as deprecated. |
| [`Library.purpose`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.purpose](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.purpose`is mapped to FHIR R4 element`Library.purpose`as`Equivalent`. |
| [`Library.usage`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.usage](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.usage`is mapped to FHIR R4 element`Library.usage`as`Equivalent`. |
| [`Library.copyright`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.copyright](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.copyright`is mapped to FHIR R4 element`Library.copyright`as`Equivalent`. |
| [`Library.copyrightLabel`](https://hl7.org/fhir/R5/Library.html#resource) | [Extension: ExtensionLibrary_CopyrightLabel](StructureDefinition-ext-R5-Library.copyrightLabel.md) | Element`Library.copyrightLabel`has a context of Library based on following the parent source element upwards and mapping to`Library`.Element`Library.copyrightLabel`has no mapping targets in FHIR R4. Typically, this is because the element has been added (is a new element). |
| [`Library.approvalDate`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.approvalDate](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.approvalDate`is mapped to FHIR R4 element`Library.approvalDate`as`Equivalent`. |
| [`Library.lastReviewDate`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.lastReviewDate](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.lastReviewDate`is mapped to FHIR R4 element`Library.lastReviewDate`as`Equivalent`. |
| [`Library.effectivePeriod`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.effectivePeriod](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.effectivePeriod`is mapped to FHIR R4 element`Library.effectivePeriod`as`Equivalent`. |
| [`Library.topic`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.topic](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.topic`is mapped to FHIR R4 element`Library.topic`as`Equivalent`.Element`Library.topic`has been flagged as deprecated. |
| [`Library.author`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.author](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.author`is mapped to FHIR R4 element`Library.author`as`Equivalent`. |
| [`Library.editor`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.editor](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.editor`is mapped to FHIR R4 element`Library.editor`as`Equivalent`. |
| [`Library.reviewer`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.reviewer](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.reviewer`is mapped to FHIR R4 element`Library.reviewer`as`Equivalent`. |
| [`Library.endorser`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.endorser](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.endorser`is mapped to FHIR R4 element`Library.endorser`as`Equivalent`. |
| [`Library.relatedArtifact`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.relatedArtifact](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.relatedArtifact`is mapped to FHIR R4 element`Library.relatedArtifact`as`Equivalent`. |
| [`Library.parameter`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.parameter](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.parameter`is mapped to FHIR R4 element`Library.parameter`as`Equivalent`. |
| [`Library.dataRequirement`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.dataRequirement](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.dataRequirement`is mapped to FHIR R4 element`Library.dataRequirement`as`Equivalent`. |
| [`Library.content`](https://hl7.org/fhir/R5/Library.html#resource) | [Library.content](https://hl7.org/fhir/R4/Library.html#resource) | Element`Library.content`is mapped to FHIR R4 element`Library.content`as`Equivalent`. |

