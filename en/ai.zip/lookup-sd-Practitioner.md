# Lookup for Profile_R5_Practitioner_R4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for Profile_R5_Practitioner_R4

### Lookup for FHIR R5 Practitioner for use in FHIR R4

The FHIR R5 resource is represented in FHIR R4 via the Practitioner resource.

Note that there is a profile defined to simplify use of this cross-version resource representation:[Profile: Practitioner](StructureDefinition-profile-Practitioner.md)

A computable version of the following element information is available in: [R5PractitionerElementMapToR4](ConceptMap-R5-Practitioner-element-map-to-R4.md)

| | | |
| :--- | :--- | :--- |
| [`Practitioner`](https://hl7.org/fhir/R5/Practitioner.html#resource) |   |   |
| [`Practitioner.meta`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.meta](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.meta`is mapped to FHIR R4 element`Practitioner.meta`as`Equivalent`. |
| [`Practitioner.implicitRules`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.implicitRules](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.implicitRules`is mapped to FHIR R4 element`Practitioner.implicitRules`as`Equivalent`. |
| [`Practitioner.language`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.language](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.language`is mapped to FHIR R4 element`Practitioner.language`as`Equivalent`. |
| [`Practitioner.text`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.text](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.text`is mapped to FHIR R4 element`Practitioner.text`as`Equivalent`. |
| [`Practitioner.contained`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.contained](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.contained`is mapped to FHIR R4 element`Practitioner.contained`as`Equivalent`. |
| [`Practitioner.identifier`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.identifier](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.identifier`is mapped to FHIR R4 element`Practitioner.identifier`as`Equivalent`. |
| [`Practitioner.active`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.active](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.active`is mapped to FHIR R4 element`Practitioner.active`as`Equivalent`. |
| [`Practitioner.name`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.name](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.name`is mapped to FHIR R4 element`Practitioner.name`as`Equivalent`. |
| [`Practitioner.telecom`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.telecom](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.telecom`is mapped to FHIR R4 element`Practitioner.telecom`as`Equivalent`. |
| [`Practitioner.gender`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.gender](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.gender`is mapped to FHIR R4 element`Practitioner.gender`as`Equivalent`. |
| [`Practitioner.birthDate`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.birthDate](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.birthDate`is mapped to FHIR R4 element`Practitioner.birthDate`as`Equivalent`. |
| [`Practitioner.deceased[x]`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Extension: ExtensionPractitioner_Deceased](StructureDefinition-ext-R5-Practitioner.deceased.md) | Element`Practitioner.deceased[x]`has a context of Practitioner based on following the parent source element upwards and mapping to`Practitioner`.Element`Practitioner.deceased[x]`has no mapping targets in FHIR R4. Typically, this is because the element has been added (is a new element). |
| [`Practitioner.address`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.address](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.address`is mapped to FHIR R4 element`Practitioner.address`as`Equivalent`. |
| [`Practitioner.photo`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.photo](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.photo`is mapped to FHIR R4 element`Practitioner.photo`as`Equivalent`. |
| [`Practitioner.qualification`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.qualification](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.qualification`is mapped to FHIR R4 element`Practitioner.qualification`as`Equivalent`. |
| [`Practitioner.qualification.identifier`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.qualification.identifier](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.qualification.identifier`is mapped to FHIR R4 element`Practitioner.qualification.identifier`as`Equivalent`. |
| [`Practitioner.qualification.code`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.qualification.code](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.qualification.code`is mapped to FHIR R4 element`Practitioner.qualification.code`as`Equivalent`. |
| [`Practitioner.qualification.period`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.qualification.period](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.qualification.period`is mapped to FHIR R4 element`Practitioner.qualification.period`as`Equivalent`. |
| [`Practitioner.qualification.issuer`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.qualification.issuer](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.qualification.issuer`is mapped to FHIR R4 element`Practitioner.qualification.issuer`as`Equivalent`. |
| [`Practitioner.communication`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Practitioner.communication](https://hl7.org/fhir/R4/Practitioner.html#resource) | Element`Practitioner.communication`is mapped to FHIR R4 element`Practitioner.communication`as`Equivalent`. |
| [`Practitioner.communication.language`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Extension: ExtensionPractitioner_Communication_Language](StructureDefinition-ext-R5-Practitioner.com.language.md) | Element`Practitioner.communication.language`has a context of Practitioner.communication based on following the parent source element upwards and mapping to`Practitioner`.Element`Practitioner.communication.language`has no mapping targets in FHIR R4. Typically, this is because the element has been added (is a new element). |
| [`Practitioner.communication.preferred`](https://hl7.org/fhir/R5/Practitioner.html#resource) | [Extension: ExtensionPractitioner_Communication_Preferred](StructureDefinition-ext-R5-Practitioner.com.preferred.md) | Element`Practitioner.communication.preferred`has a context of Practitioner.communication based on following the parent source element upwards and mapping to`Practitioner`.Element`Practitioner.communication.preferred`has no mapping targets in FHIR R4. Typically, this is because the element has been added (is a new element). |

