# Lookup for R5FhirpathTypesForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5FhirpathTypesForR4

### Lookup for FHIR R5 ValueSet FHIRPathTypes:http://hl7.org/fhir/ValueSet/fhirpath-types for use in FHIR R4

The FHIR R5 ValueSet FHIRPathTypes has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.Boolean` | Boolean | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.Date` | Date | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.DateTime` | DateTime | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.Decimal` | Decimal | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.Integer` | Integer | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.String` | String | Yes |   |   |   |
| `http://hl7.org/fhir/CodeSystem/fhirpath-types` | `http://hl7.org/fhirpath/System.Time` | Time | Yes |   |   |   |

