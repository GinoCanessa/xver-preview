# Lookup for R5FundsreserveForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5FundsreserveForR4

### Lookup for FHIR R5 ValueSet FundsReservationCodes:http://hl7.org/fhir/ValueSet/fundsreserve for use in FHIR R4

The FHIR R5 ValueSet FundsReservationCodes maps to the FHIR R4 ValueSet Funds Reservation Codes:[`http://hl7.org/fhir/ValueSet/fundsreserve`](https://hl7.org/fhir/R4/valueset-fundsreserve.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/fundsreserve` | `none` | None | No | `http://terminology.hl7.org/CodeSystem/fundsreserve` | `none` | None |
| `http://terminology.hl7.org/CodeSystem/fundsreserve` | `patient` | Patient | No | `http://terminology.hl7.org/CodeSystem/fundsreserve` | `patient` | Patient |
| `http://terminology.hl7.org/CodeSystem/fundsreserve` | `provider` | Provider | No | `http://terminology.hl7.org/CodeSystem/fundsreserve` | `provider` | Provider |

