# Lookup for R5ExpansionProcessingRuleForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ExpansionProcessingRuleForR4

### Lookup for FHIR R5 ValueSet ExpansionProcessingRule:http://terminology.hl7.org/ValueSet/expansion-processing-rule for use in FHIR R4

The FHIR R5 ValueSet ExpansionProcessingRule has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/expansion-processing-rule` | `all-codes` | All Codes | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/expansion-processing-rule` | `groups-only` | Groups Only | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/expansion-processing-rule` | `ungrouped` | Groups + Ungrouped codes | Yes |   |   |   |

