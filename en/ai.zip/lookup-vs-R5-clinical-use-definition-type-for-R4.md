# Lookup for R5ClinicalUseDefinitionTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClinicalUseDefinitionTypeForR4

### Lookup for FHIR R5 ValueSet ClinicalUseDefinitionType:http://hl7.org/fhir/ValueSet/clinical-use-definition-type for use in FHIR R4

The FHIR R5 ValueSet ClinicalUseDefinitionType has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/clinical-use-definition-type` | `contraindication` | Contraindication | Yes |   |   |   |
| `http://hl7.org/fhir/clinical-use-definition-type` | `indication` | Indication | Yes |   |   |   |
| `http://hl7.org/fhir/clinical-use-definition-type` | `interaction` | Interaction | Yes |   |   |   |
| `http://hl7.org/fhir/clinical-use-definition-type` | `undesirable-effect` | Undesirable Effect | Yes |   |   |   |
| `http://hl7.org/fhir/clinical-use-definition-type` | `warning` | Warning | Yes |   |   |   |

