# Lookup for R5ExamplescenarioActorTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ExamplescenarioActorTypeForR4

### Lookup for FHIR R5 ValueSet ExampleScenarioActorType:http://hl7.org/fhir/ValueSet/examplescenario-actor-type for use in FHIR R4

The FHIR R5 ValueSet ExampleScenarioActorType maps to the FHIR R4 ValueSet ExampleScenarioActorType:[`http://hl7.org/fhir/ValueSet/examplescenario-actor-type`](https://hl7.org/fhir/R4/valueset-examplescenario-actor-type.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/examplescenario-actor-type` | `person` | Person | No | `http://hl7.org/fhir/examplescenario-actor-type` | `person` | Person |
| `http://hl7.org/fhir/examplescenario-actor-type` | `system` | System | No | `http://hl7.org/fhir/examplescenario-actor-type` | `entity` | System |

