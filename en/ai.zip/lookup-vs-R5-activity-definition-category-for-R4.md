# Lookup for R5ActivityDefinitionCategoryForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ActivityDefinitionCategoryForR4

### Lookup for FHIR R5 ValueSet ActivityDefinitionCategory:http://terminology.hl7.org/ValueSet/activity-definition-category for use in FHIR R4

The FHIR R5 ValueSet ActivityDefinitionCategory has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/activity-definition-category` | `assessment` | Assessment | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/activity-definition-category` | `education` | Education | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/activity-definition-category` | `treatment` | Treatment | Yes |   |   |   |

