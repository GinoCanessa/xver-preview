# Lookup for R5CertaintyTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CertaintyTypeForR4

### Lookup for FHIR R5 ValueSet EvidenceCertaintyType:http://hl7.org/fhir/ValueSet/certainty-type for use in FHIR R4

The FHIR R5 ValueSet EvidenceCertaintyType has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/certainty-type` | `DoseResponseGradient` | Dose response gradient | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `Imprecision` | Imprecision | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `Inconsistency` | Inconsistency | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `Indirectness` | Indirectness | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `LargeEffect` | Large effect | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `Overall` | Overall certainty | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `PlausibleConfounding` | Plausible confounding | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `PublicationBias` | Publication bias | Yes |   |   |   |
| `http://hl7.org/fhir/certainty-type` | `RiskOfBias` | Risk of bias | Yes |   |   |   |

