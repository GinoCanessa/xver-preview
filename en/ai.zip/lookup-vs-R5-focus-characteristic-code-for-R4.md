# Lookup for R5FocusCharacteristicCodeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5FocusCharacteristicCodeForR4

### Lookup for FHIR R5 ValueSet FocusCharacteristicCode:http://hl7.org/fhir/ValueSet/focus-characteristic-code for use in FHIR R4

The FHIR R5 ValueSet FocusCharacteristicCode has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/focus-characteristic-code` | `citation` | Citation | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `clinical-outcomes-observed` | Observed outcomes are clinical outcomes | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `comparator` | Comparator | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `exposure` | Exposure | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `medication-exposures` | Medication exposures | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `outcome` | Outcome | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `population` | Population | Yes |   |   |   |
| `http://hl7.org/fhir/focus-characteristic-code` | `study-type` | Study type | Yes |   |   |   |

