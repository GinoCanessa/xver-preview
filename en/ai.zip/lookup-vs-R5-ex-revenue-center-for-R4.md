# Lookup for R5ExRevenueCenterForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ExRevenueCenterForR4

### Lookup for FHIR R5 ValueSet ExampleRevenueCenterCodes:http://hl7.org/fhir/ValueSet/ex-revenue-center for use in FHIR R4

The FHIR R5 ValueSet ExampleRevenueCenterCodes maps to the FHIR R4 ValueSet ExampleRevenueCenterCodes:[`http://hl7.org/fhir/ValueSet/ex-revenue-center`](https://hl7.org/fhir/R4/valueset-ex-revenue-center.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/ex-revenue-center` | `0010` | Vision Clinic | No | `http://terminology.hl7.org/CodeSystem/ex-revenue-center` | `0010` | Vision Clinic |
| `http://terminology.hl7.org/CodeSystem/ex-revenue-center` | `0011` | Dental Clinic | Yes |   |   |   |
| `http://terminology.hl7.org/CodeSystem/ex-revenue-center` | `1001` | Emergency | Yes |   |   |   |

