# Lookup for R5FlagStatusForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5FlagStatusForR4

### Lookup for FHIR R5 ValueSet FlagStatus:http://hl7.org/fhir/ValueSet/flag-status for use in FHIR R4

The FHIR R5 ValueSet FlagStatus maps to the FHIR R4 ValueSet FlagStatus:[`http://hl7.org/fhir/ValueSet/flag-status`](https://hl7.org/fhir/R4/valueset-flag-status.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/flag-status` | `active` | Active | No | `http://hl7.org/fhir/flag-status` | `active` | Active |
| `http://hl7.org/fhir/flag-status` | `entered-in-error` | Entered in Error | No | `http://hl7.org/fhir/flag-status` | `entered-in-error` | Entered in Error |
| `http://hl7.org/fhir/flag-status` | `inactive` | Inactive | No | `http://hl7.org/fhir/flag-status` | `inactive` | Inactive |

