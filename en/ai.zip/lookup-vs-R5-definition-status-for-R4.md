# Lookup for R5DefinitionStatusForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5DefinitionStatusForR4

### Lookup for FHIR R5 ValueSet DefinitionStatus:http://terminology.hl7.org/ValueSet/definition-status for use in FHIR R4

The FHIR R5 ValueSet DefinitionStatus maps to the FHIR R4 ValueSet DefinitionStatus:[`http://hl7.org/fhir/ValueSet/definition-status`](https://hl7.org/fhir/R4/valueset-definition-status.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/definition-status` | `active` | Active | No | `http://terminology.hl7.org/CodeSystem/definition-status` | `active` | Active |
| `http://terminology.hl7.org/CodeSystem/definition-status` | `draft` | Draft | No | `http://terminology.hl7.org/CodeSystem/definition-status` | `draft` | Draft |
| `http://terminology.hl7.org/CodeSystem/definition-status` | `unknown` | Unknown | No | `http://terminology.hl7.org/CodeSystem/definition-status` | `unknown` | Unknown |
| `http://terminology.hl7.org/CodeSystem/definition-status` | `withdrawn` | Withdrawn | No | `http://terminology.hl7.org/CodeSystem/definition-status` | `withdrawn` | Withdrawn |

