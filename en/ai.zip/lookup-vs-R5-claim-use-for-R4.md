# Lookup for R5ClaimUseForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ClaimUseForR4

### Lookup for FHIR R5 ValueSet Use:http://hl7.org/fhir/ValueSet/claim-use for use in FHIR R4

The FHIR R5 ValueSet Use maps to the FHIR R4 ValueSet Use:[`http://hl7.org/fhir/ValueSet/claim-use`](https://hl7.org/fhir/R4/valueset-claim-use.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/claim-use` | `claim` | Claim | No | `http://hl7.org/fhir/claim-use` | `claim` | Claim |
| `http://hl7.org/fhir/claim-use` | `preauthorization` | Preauthorization | No | `http://hl7.org/fhir/claim-use` | `preauthorization` | Preauthorization |
| `http://hl7.org/fhir/claim-use` | `predetermination` | Predetermination | No | `http://hl7.org/fhir/claim-use` | `predetermination` | Predetermination |

