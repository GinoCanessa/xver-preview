# Lookup for R5ContractSecurityControlForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5ContractSecurityControlForR4

### Lookup for FHIR R5 ValueSet ContractResourceSecurityControlCodes:http://hl7.org/fhir/ValueSet/contract-security-control for use in FHIR R4

The FHIR R5 ValueSet ContractResourceSecurityControlCodes maps to the FHIR R4 ValueSet ContractResourceSecurityControlCodes:[`http://hl7.org/fhir/ValueSet/contract-security-control`](https://hl7.org/fhir/R4/valueset-contract-security-control.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/contract-security-control` | `policy` | Policy | No | `http://hl7.org/fhir/contract-security-control` | `policy` | Policy |

