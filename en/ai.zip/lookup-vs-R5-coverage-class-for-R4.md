# Lookup for R5CoverageClassForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CoverageClassForR4

### Lookup for FHIR R5 ValueSet CoverageClassCodes:http://hl7.org/fhir/ValueSet/coverage-class for use in FHIR R4

The FHIR R5 ValueSet CoverageClassCodes maps to the FHIR R4 ValueSet CoverageClassCodes:[`http://hl7.org/fhir/ValueSet/coverage-class`](https://hl7.org/fhir/R4/valueset-coverage-class.html)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `class` | Class | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `class` | Class |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `group` | Group | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `group` | Group |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `plan` | Plan | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `plan` | Plan |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxbin` | RX BIN | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxbin` | RX BIN |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxgroup` | RX Group | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxgroup` | RX Group |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxid` | RX Id | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxid` | RX Id |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxpcn` | RX PCN | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `rxpcn` | RX PCN |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `sequence` | Sequence | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `sequence` | Sequence |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `subclass` | SubClass | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `subclass` | SubClass |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `subgroup` | SubGroup | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `subgroup` | SubGroup |
| `http://terminology.hl7.org/CodeSystem/coverage-class` | `subplan` | SubPlan | No | `http://terminology.hl7.org/CodeSystem/coverage-class` | `subplan` | SubPlan |

