# Lookup for R5AuditEventSeverityForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5AuditEventSeverityForR4

### Lookup for FHIR R5 ValueSet AuditEventSeverity:http://hl7.org/fhir/ValueSet/audit-event-severity for use in FHIR R4

The FHIR R5 ValueSet AuditEventSeverity has no mapping to FHIR R4.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/audit-event-severity` | `alert` | Alert | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `critical` | Critical | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `debug` | Debug | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `emergency` | Emergency | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `error` | Error | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `informational` | Informational | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `notice` | Notice | Yes |   |   |   |
| `http://hl7.org/fhir/audit-event-severity` | `warning` | Warning | Yes |   |   |   |

