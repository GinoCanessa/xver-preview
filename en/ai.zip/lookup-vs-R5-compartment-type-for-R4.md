# Lookup for R5CompartmentTypeForR4 - Extensions for Using Data Elements from FHIR R5 in FHIR R4 v0.1.0

## Lookup for R5CompartmentTypeForR4

### Lookup for FHIR R5 ValueSet CompartmentType:http://hl7.org/fhir/ValueSet/compartment-type for use in FHIR R4

The FHIR R5 ValueSet CompartmentType maps to the FHIR R4 ValueSet CompartmentType:[`http://hl7.org/fhir/ValueSet/compartment-type`](https://hl7.org/fhir/R4/valueset-compartment-type.html)

A computable version of the following mapping information is available in: [R5CompartmentTypeForR4](ConceptMap-Map-R5-compartment-type-for-R4.md)

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `http://hl7.org/fhir/compartment-type` | `Device` | Device | No | `http://hl7.org/fhir/compartment-type` | `Device` | Device |
| `http://hl7.org/fhir/compartment-type` | `Encounter` | Encounter | No | `http://hl7.org/fhir/compartment-type` | `Encounter` | Encounter |
| `http://hl7.org/fhir/compartment-type` | `EpisodeOfCare` | EpisodeOfCare | Yes |   |   |   |
| `http://hl7.org/fhir/compartment-type` | `Patient` | Patient | No | `http://hl7.org/fhir/compartment-type` | `Patient` | Patient |
| `http://hl7.org/fhir/compartment-type` | `Practitioner` | Practitioner | No | `http://hl7.org/fhir/compartment-type` | `Practitioner` | Practitioner |
| `http://hl7.org/fhir/compartment-type` | `RelatedPerson` | RelatedPerson | No | `http://hl7.org/fhir/compartment-type` | `RelatedPerson` | RelatedPerson |

